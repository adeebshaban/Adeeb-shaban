public class Question2 { //Question2 is a public class which can be accessed anywhere

	public static void main(String[] args) { //main method of a java program
		int num1=3; //defining num1 as an integer variable
		int num2=7; //defining num2 as an integer variable
		int sum; //defining sum as an integer variable
		
		sum = num1+num2; //the equation of the sum as in number 1 + number 2 = sum
		System.out.println(sum); //printing out the sum of two numbers on the output screen
	}

}