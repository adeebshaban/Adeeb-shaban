import java.util.Scanner; //importing the class Scanner to scan entered numbers

public class Question5 { //Question5 is a public class which can be accessed anywhere
	
	public static void main(String[] args) { //main method of a java program
		
		Scanner number1 = new Scanner(System.in); //adding a scanner to scan the variable number1
		Scanner number2 = new Scanner(System.in); //adding a scanner to scan the variable number2
		
		System.out.println("Enter Number one: "); //printing out a message in the output screen
		int num1 = number1.nextInt(); //defining a variable called "num1" to add the scanned number1
		
		System.out.println("Enter Number two: "); //printing out a message in the output screen
		int num2 = number2.nextInt(); //defining a variable called "num2" to add the scanned number2
		
		if (num1>num2) { //if entered num1 is greater than num2 **Condition**
			
			System.out.println("Number one is greater than Number two"); //printing out a message in the output screen
			
		}
		if (num1<num2) { //if entered num1 is less than num2 **Condition**
			System.out.println("Number two is greater than Number one"); //printing out a message in the output screen
		}
		if (num1 == num2) { //if entered num1 and num2 are equal **Condition**
			System.out.println("The numbers are equals");
		}
	}

}

