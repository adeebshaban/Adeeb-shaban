
public class Question1 { //Question1 is a public class which can be accessed anywhere

	public static void main(String[] args) { //main method of a java program
		System.out.println("Name: Adeeb Shaban\t\t" + "University's ID: 18110004"); //printing in the output screen
		
	}

}
