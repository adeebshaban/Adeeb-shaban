import javax.swing.JOptionPane; //importing the class JOption to get a dialog Box

public class Question3 { //Question3 is a public class which can be accessed anywhere
	
	public static void main(String[] args) { //main method of a java program
		
		JOptionPane.showMessageDialog(null, "Hello World!"); //To get a dialog box which pops up the message "Hello World!"

	}
}

