import java.util.Scanner; //importing the class Scanner to scan entered numbers

public class Question4 { //Question4 is a public class which can be accessed anywhere
	
	public static void main(String[] args) { //main method of a java program

		Scanner num1 = new Scanner(System.in); //adding a scanner to scan the variable num1
		
		Scanner num2 = new Scanner(System.in); //adding a scanner to scan the variable num2
		 
		System.out.println("Enter Number 1: ");  //printing out a message to enter number one 
		
		int number1 = num1.nextInt(); //defining an integer variable called "number1" to store the scanned num1
		
		System.out.println("Enter Number 2: "); //printing out a message to enter number two
		
		int number2 = num2.nextInt(); //defining an integer variable called "number2" to store the scanned num2
		
		int sum = number1+number2; // defining an integer variable called "sum" to store the scanned and stored in number1 and number two and adding the equation which is the sum between them
		
		System.out.println("The Sum of two numbers is: " + sum); //printing out the sum between two numbers in the output screen
	}
}
