import java.util.Scanner; //importing the class Scanner to scan entered numbers
import javax.swing.JOptionPane; //importing the class JOption to get a dialog Box

public class Question7 { //Question7 is a public class which can be accessed anywhere
public static void main(String[] args){ //main method of a java program
		
		Scanner num1 = new Scanner(System.in); //adding a scanner to scan the variable num1
		Scanner num2 = new Scanner(System.in); //adding a scanner to scan the variable num2
		Scanner opera = new Scanner(System.in); //adding a scanner to scan the variable opera
		
		float total = 0;  //defining a float variable called "total" 

		char X2; //defining a character variable called X2 
		
		
		for (int i = 0;i<100;i++){ //for loop from 0 to 100
			
			
		System.out.println("Enter Number 1: "); //printing out a message on the screen

		float n1 = num1.nextFloat(); //defining a float variable to store in it a scanned number
		
		System.out.println("Enter Number 2: "); //printing out a message on the screen
		
		float n2 = num2.nextFloat(); //defining a float variable to store in it a scanned number
		

		System.out.println("Enter the operation: "); //printing out a message on the screen
				
	X2 = opera.next().charAt(0); //defining a variable to store in it a scanned character
	
		switch (X2) { //switch loop 
		case '+': //if the entered operation is + 
			total = n1+n2; //equation
			break; //quits the switch loop
			
		case '-': //if the entered operation is - 
			total = n1-n2; //equation
			break; //quits the switch loop
			
		case '*': //if the entered operation is *
		total = n1*n2; //equation
			break; //quits the switch loop
			
		case '/': //if the entered operation is /
		total = n1/n2; //equation 
			break; //quits the switch loop
			
		default: //default is used when entered operators isn't one of the previous ones in the cases 
			
			JOptionPane.showMessageDialog(null, "There's something wrong!! Try Again."); //pops up a dialog 
			
		}
		
		System.out.println(total); //printing out the total in the output screen 
		
		System.out.println("\n\nEnter 1 to rerun the program or 0 to exit the program"); //printing out a message in the output screen
		
		Scanner cont = new Scanner(System.in); //adding a scanner

		int n3 = cont.nextInt(); //defining an integer variable to add the scanned number
		
		if (n3 == 1) //if entered n3 = 1
		{
			i = 0;
			
		}
		else
		{
			i = 100;
		}
		
	}

	}
}
