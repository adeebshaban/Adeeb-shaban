
public class Question6 { //Question6 is a public class which can be accessed anywhere
	public static void main(String[] args) { //main method of a java program
		int num=0; //defining a variable called num to store the numbers in it
		
		for (int i = 0; i <=100; i++) { //for loop to run the counter for 100 times starting with 0
			
			num+=i; // num = num + i
		}
		
		System.out.println("The Total number = " + num); //printing out the num
	}
}
