<?php
  $to = "adeebonsteam@gmail.com";
  $subject = "Contact Form from MOE";
  $message1 = $_POST['name'];
  $message2 = $_POST['email'];
  $headers = "from: $message2";
  if (mail($to,$subject,$message1)) {
        echo "sucess";
  }
  else {
    echo "failed";
  }
 ?>
