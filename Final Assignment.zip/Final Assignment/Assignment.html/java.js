$(".menu-activator").on("click", function() {
  $("body").toggleClass("menu-active");
});